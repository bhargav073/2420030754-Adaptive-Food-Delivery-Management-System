export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret:
    process.env.JWT_SECRET || "cnad32-default-secret-key-for-local-dev",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  oAuthPortalUrl: process.env.VITE_OAUTH_PORTAL_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  localAuthName: process.env.CNAD32_LOCAL_AUTH_NAME?.trim() || "Local Operator",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  kubeConfigPath: process.env.KUBECONFIG ?? "",
  kubeConfigBase64: process.env.CNAD32_KUBECONFIG_B64 ?? "",
  workspaceHostSuffix: process.env.CNAD32_WORKSPACE_HOST_SUFFIX ?? "",
  ingressClassName: process.env.CNAD32_INGRESS_CLASS_NAME ?? "",
};
